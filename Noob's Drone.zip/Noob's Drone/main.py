import random  # For generating random numbers
import sys  # Using sys.exit to exit the program
import pygame
from pygame.locals import *  # Basic pygame imports

# Global Variables for the game
FPS = 32
SCREENWIDTH = 600
SCREENHEIGHT = 500
SCREEN = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))
GROUNDY = SCREENHEIGHT * 0.8
GAME_SPRITES = {}
GAME_SOUNDS = {}
PLAYER = 'gallery/sprites/drone.png'
BACKGROUND = 'gallery/sprites/background.png'
TRUSS = 'gallery/sprites/truss.png'


# button
class button:
    def __init__(self, color, x, y, width, height, text=''):
        self.color = color
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text

    def draw(self, SCREEN, outline=None):
        
        if outline:
            pygame.draw.rect(SCREEN, outline, (self.x - 2, self.y - 2, self.width + 4, self.height + 4), 0)

        pygame.draw.rect(SCREEN, self.color, (self.x, self.y, self.width, self.height), 0)

        if self.text != '':
            font1 = pygame.font.SysFont(None, 25)
            text = font1.render(self.text, 1, (0, 0, 0))
            SCREEN.blit(text, (
                self.x + (self.width / 2 - text.get_width() / 2), self.y + (self.height / 2 - text.get_height() / 2)))

    def isOver(self, pos):
        # Pos is the mouse position or a tuple of (x,y) coordinates
        if self.x < pos[0] < self.x + self.width:
            if self.y < pos[1] < self.y + self.height:
                return True

        return False


# welcome screen
def WelcomeScreen():
    """
    Shows welcome images on the screen
    """
    greenButton = button((0, 255, 0), 250, 320, 100, 30, 'CONTINUE')
    playerx = int(SCREENWIDTH / 5)
    playery = int((SCREENHEIGHT - GAME_SPRITES['player'].get_height()) / 2)
    messagex = int((SCREENWIDTH - GAME_SPRITES['message'].get_width()) / 1.3)
    messagey = int(SCREENHEIGHT * 0.15)
    basex = 0
    while True:
        for event in pygame.event.get():
            # by clicking on cross button, the game closes
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()

            # by pressing space or up key, the game starts
            elif event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                return
            else:
                SCREEN.blit(GAME_SPRITES['background'], (0, 0))
                SCREEN.blit(GAME_SPRITES['player'], (playerx, playery))
                SCREEN.blit(GAME_SPRITES['message'], (messagex, messagey))
                SCREEN.blit(GAME_SPRITES['base'], (basex, GROUNDY))
                pygame.display.update()
                FPSCLOCK.tick(FPS)


def mainGame():
    score = 0
    playerx = int(SCREENWIDTH / 5)
    playery = int(SCREENWIDTH / 2)
    basex = 0

    # Creating 2 Trusses for blitting on the screen
    newTruss1 = getRandomTruss()
    newTruss2 = getRandomTruss()

    # List of upper Trusses
    upperTrusses = [
        {'x': SCREENWIDTH + 200, 'y': newTruss1[0]['y']},
        {'x': SCREENWIDTH + 200 + (SCREENWIDTH / 2), 'y': newTruss2[0]['y']},
    ]
    # my List of lower Trusses
    lowerTrusses = [
        {'x': SCREENWIDTH + 200, 'y': newTruss1[1]['y']},
        {'x': SCREENWIDTH + 200 + (SCREENWIDTH / 2), 'y': newTruss2[1]['y']},
    ]

    trussVelX = -4

    playerVelY = -9
    playerMaxVelY = 10
    playerMinVelY = -8
    playerAccY = 1

    playerFlapAccv = -8  # velocity while flapping
    playerFlapped = False  # It is true only when the bird is flapping

    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                if playery > 0:
                    playerVelY = playerFlapAccv
                    playerFlapped = True
                    GAME_SOUNDS['wing'].play()

        crashTest = isCollide(playerx, playery, upperTrusses, lowerTrusses)  # This function will return true if the player is crashed
        if crashTest:
            return

            # checking the score
        playerMidPos = playerx + GAME_SPRITES['player'].get_width() / 2
        for truss in upperTrusses:
            trussMidPos = truss['x'] + GAME_SPRITES['truss'][0].get_width() / 2
            if trussMidPos <= playerMidPos < trussMidPos + 4:
                score += 1
                print(f"Your score is {score}")
                GAME_SOUNDS['point'].play()

        if playerVelY < playerMaxVelY and not playerFlapped:
            playerVelY += playerAccY

        if playerFlapped:
            playerFlapped = False
        playerHeight = GAME_SPRITES['player'].get_height()
        playery = playery + min(playerVelY, GROUNDY - playery - playerHeight)

        # move Trusses to the left
        for upperTruss, lowerTruss in zip(upperTrusses, lowerTrusses):
            upperTruss['x'] += trussVelX
            lowerTruss['x'] += trussVelX

        # Add a new Truss when the first is about to cross the leftmost part of the screen
        if 0 < upperTrusses[0]['x'] < 5:
            newTruss = getRandomTruss()
            upperTrusses.append(newTruss[0])
            lowerTrusses.append(newTruss[1])

        # if the Truss is out of the screen, remove it
        if upperTrusses[0]['x'] < -GAME_SPRITES['truss'][0].get_width():
            upperTrusses.pop(0)
            lowerTrusses.pop(0)

        # bliting the game sprites
        SCREEN.blit(GAME_SPRITES['background'], (0, 0))
        for upperTruss, lowerTruss in zip(upperTrusses, lowerTrusses):
            SCREEN.blit(GAME_SPRITES['truss'][0], (upperTruss['x'], upperTruss['y']))
            SCREEN.blit(GAME_SPRITES['truss'][1], (lowerTruss['x'], lowerTruss['y']))

        SCREEN.blit(GAME_SPRITES['base'], (basex, GROUNDY))
        SCREEN.blit(GAME_SPRITES['player'], (playerx, playery))
        myDigits = [int(x) for x in list(str(score))]
        width = 0
        for digit in myDigits:
            width += GAME_SPRITES['numbers'][digit].get_width()
        Xoffset = (SCREENWIDTH - width) / 2

        for digit in myDigits:
            SCREEN.blit(GAME_SPRITES['numbers'][digit], (Xoffset, SCREENHEIGHT * 0.12))
            Xoffset += GAME_SPRITES['numbers'][digit].get_width()
        pygame.display.update()
        FPSCLOCK.tick(FPS)


def isCollide(playerx, playery, upperTrusses, lowerTrusses):
    if playery > GROUNDY - 25 or playery < 0:
        GAME_SOUNDS['hit'].play()
        return True

    for truss in upperTrusses:
        trussHeight = GAME_SPRITES['truss'][0].get_height()
        if (playery < trussHeight + truss['y'] and abs(playerx - truss['x']) < GAME_SPRITES['truss'][0].get_width()):
            GAME_SOUNDS['hit'].play()
            return True

    for truss in lowerTrusses:
        if (playery + GAME_SPRITES['player'].get_height() > truss['y']) and abs(playerx - truss['x']) < \
                GAME_SPRITES['truss'][0].get_width():
            GAME_SOUNDS['hit'].play()
            return True

    return False


def getRandomTruss():
    """
    Generate positions of two pipes(one bottom straight and one top rotated ) for blitting on the screen
    """
    trussHeight = GAME_SPRITES['truss'][0].get_height()
    offset = SCREENHEIGHT / 3
    y2 = offset + random.randrange(0, int(SCREENHEIGHT - GAME_SPRITES['base'].get_height() - 1.2 * offset))
    trussX = SCREENWIDTH + 10
    y1 = trussHeight - y2 + offset
    truss = [
        {'x': trussX, 'y': -y1},  # upper Truss
        {'x': trussX, 'y': y2}  # lower Truss
    ]
    return truss


if __name__ == "__main__":
    # This will be the main point from where our game will start
    pygame.init()  # Initialize all pygame's modules
    FPSCLOCK = pygame.time.Clock()
    pygame.display.set_caption('Noob\'s Drone')
    GAME_SPRITES['numbers'] = (
        pygame.image.load('gallery/sprites/0.png').convert_alpha(),
        pygame.image.load('gallery/sprites/1.png').convert_alpha(),
        pygame.image.load('gallery/sprites/2.png').convert_alpha(),
        pygame.image.load('gallery/sprites/3.png').convert_alpha(),
        pygame.image.load('gallery/sprites/4.png').convert_alpha(),
        pygame.image.load('gallery/sprites/5.png').convert_alpha(),
        pygame.image.load('gallery/sprites/6.png').convert_alpha(),
        pygame.image.load('gallery/sprites/7.png').convert_alpha(),
        pygame.image.load('gallery/sprites/8.png').convert_alpha(),
        pygame.image.load('gallery/sprites/9.png').convert_alpha(),
    )

    GAME_SPRITES['message'] = pygame.image.load('gallery/sprites/message.png').convert_alpha()
    GAME_SPRITES['base'] = pygame.image.load('gallery/sprites/base.png').convert_alpha()
    GAME_SPRITES['truss'] = (pygame.transform.rotate(pygame.image.load(TRUSS).convert_alpha(), 180),
                            pygame.image.load(TRUSS).convert_alpha()
                            )

    # Game sounds
    GAME_SOUNDS['die'] = pygame.mixer.Sound('gallery/audio/die.wav')
    GAME_SOUNDS['hit'] = pygame.mixer.Sound('gallery/audio/hit.wav')
    GAME_SOUNDS['point'] = pygame.mixer.Sound('gallery/audio/point.wav')
    GAME_SOUNDS['swoosh'] = pygame.mixer.Sound('gallery/audio/swoosh.wav')
    GAME_SOUNDS['wing'] = pygame.mixer.Sound('gallery/audio/wing.wav')

    GAME_SPRITES['background'] = pygame.image.load(BACKGROUND).convert()
    GAME_SPRITES['player'] = pygame.image.load(PLAYER).convert_alpha()

    while True:
        WelcomeScreen()  # Shows welcome screen to the user until he presses a button
        mainGame()  # This is the main game function
